# 防詐騙Line機器人整理版

這是防詐騙Line機器人的整理版本，包含所有必要的文件。

## 目錄結構

```
clean_project/
├── anti-fraud-clean/          # 主程式目錄
│   ├── app.py                 # 主程式
│   ├── firebase_manager.py    # Firebase數據管理模組
│   ├── fix_json_display.py    # JSON格式處理工具
│   ├── fraud_tactics.json     # 詐騙話術資料庫
│   ├── potato_game_questions.json # 遊戲題庫
│   ├── requirements.txt       # 依賴套件清單
│   └── templates/             # 網頁模板目錄
│       ├── index.html         # 主頁模板
│       └── statistics.html    # 統計頁面模板
└── linebot-anti-fraud/        # 配置檔案目錄
    └── .env                   # 環境變數設定檔
```

## 運行方式

1. 安裝依賴套件：
   ```
   cd clean_project/anti-fraud-clean
   pip install -r requirements.txt
   ```

2. 確保 .env 文件包含所有必要的API金鑰和憑證

3. 啟動服務：
   ```
   cd clean_project/anti-fraud-clean
   python app.py
   ```
   
## 功能說明

- 詐騙風險分析：分析用戶提供的訊息或URL是否存在詐騙風險
- 詐騙類型查詢：提供各種常見詐騙類型的資訊
- 「選哪顆土豆」遊戲：通過遊戲形式學習辨識詐騙訊息
- 統計功能：展示詐騙類型統計數據 